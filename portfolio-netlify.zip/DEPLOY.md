# Déploiement — Portfolio Estevao / Mwinda Group

1. Aller sur https://app.netlify.com/drop
2. Glisser-déposer le ZIP (ou ce dossier) — le site est en ligne en ~30 s.
3. Formulaire : Netlify détecte automatiquement le formulaire `portfolio-contact`
   (soumissions visibles dans l'onglet Forms du dashboard).
4. Vidéo de fond : servie depuis le CDN Higgsfield (autorisé dans netlify.toml).
   Pour l'auto-héberger (recommandé, l'URL CDN peut expirer) :
   curl -L -o assets/clips/bg-tech.mp4 "https://d8j0ntlcm91z4.cloudfront.net/user_3G9osobYr0aAENArzSDrqEFJFgW/hf_20260719_053719_30b17f73-3199-47f6-aaf2-5d2d18699850.mp4"
   puis redéployer — le site la préférera automatiquement au CDN.
5. À confirmer avant mise en ligne : les 2 stats (« à confirmer ») et l'URL LinkedIn
   dans index.html.
