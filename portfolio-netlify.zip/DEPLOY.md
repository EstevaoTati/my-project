# Déploiement — Landing page Estevao / Mwinda Group

## Mise en ligne (30 secondes)
1. https://app.netlify.com/drop
2. Glisser-déposer ce dossier (ou le ZIP). Le site est en ligne.
3. Le formulaire `portfolio-contact` est détecté automatiquement par Netlify
   (soumissions dans l'onglet Forms).

## Fond animé
Deux couches, toutes deux permanentes pendant le scroll :
- réseau neuronal calculé dans la page (toujours actif, aucun fichier requis) ;
- vidéo 3D IA de 8 s générée sur Higgsfield, jouée en boucle sous un voile
  dégradé. Elle est servie depuis le CDN Higgsfield, déjà autorisé dans la
  CSP de ce netlify.toml.

Pour l'auto-héberger (recommandé, l'URL CDN peut expirer) :

    curl -L -o assets/clips/bg-tech.mp4 \
      "https://d8j0ntlcm91z4.cloudfront.net/user_3G9osobYr0aAENArzSDrqEFJFgW/hf_20260730_005955_b7dfa171-e171-4ecd-8108-44f7dc4af7a8.mp4"

puis redéployer : le site préfère automatiquement le fichier local.

## À vérifier avant mise en ligne
- URL LinkedIn dans index.html (actuellement linkedin.com/in/estevao-macumba).
- Les chiffres affichés : 4+ ans, 50+ clients, 15+ masterclass, 43 projets.
