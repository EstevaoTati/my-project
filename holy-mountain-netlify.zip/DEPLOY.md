# Deploying this package

This folder is the whole site. It needs no build step and no dependencies.

## Drag and drop (fastest)

1. Open <https://app.netlify.com/drop>.
2. Drag this folder (or the .zip) onto the page.
3. Netlify gives you a URL straight away. Rename the site, or attach a domain,
   from **Site configuration → Domain management**.

`_headers` and `_redirects` are read automatically. `netlify.toml` says the
same thing and is what a CLI or Git deploy reads instead.

## Netlify CLI

    netlify deploy --dir=. --prod

## After the first deploy — three things

1. **Turn on form notifications.** The contact and prayer form posts to Netlify
   Forms. Go to **Forms → contact → Settings → Form notifications** and add the
   church's email, or submissions will sit in the dashboard unseen.
2. **Fill in the remaining values.** Open `assets/js/site.js` and edit the block
   at the top marked `▼▼ EDIT THIS BLOCK ▼▼`: the street address, the maps link
   and the four social profile URLs. Then set `draft: false` to remove the amber
   banner. Re-deploy.
3. **Check the hero animates.** The emblem clip is proxied from a CDN by the
   redirect rule. If it shows a still image instead of turning, run
   `./fetch-video.sh` to download the clip into `assets/clips/` and re-deploy —
   a real file there wins over the proxy.

## What is in here

- `index.html`, `thanks/` — the site and its form confirmation page
- `assets/` — stylesheet, script, self-hosted fonts, images
- `_headers`, `_redirects`, `netlify.toml` — security headers and the clip proxy
- `README.md` — how the site is put together and what the church can edit
- `fetch-video.sh` — pulls the clip in so the site depends on nothing external
