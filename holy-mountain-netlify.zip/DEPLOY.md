# Deploying this package

This folder is the whole site. It needs no build step and no dependencies.

## Drag and drop (fastest)

1. Open <https://app.netlify.com/drop>.
2. Drag this folder (or the .zip) onto the page.
3. Netlify gives you a URL straight away. Rename the site, or attach a domain,
   from **Site configuration → Domain management**.

`_headers` and `_redirects` are read automatically. `netlify.toml` says the
same thing and is what a CLI or Git deploy reads instead.

## Netlify CLI

    netlify deploy --dir=. --prod

## After attaching the domain — do this first

**Provision the certificate and turn on Force HTTPS.** In **Domain management →
HTTPS**, wait for Netlify to issue the Let's Encrypt certificate (it needs the
DNS to point at Netlify first), then switch **Force HTTPS** on. Until that is
done the domain is served over plain `http://`, and a browser showing the
"Not secure" warning is the least of it — anyone typing the address gets the
unencrypted site.

This package's security policy no longer contains `upgrade-insecure-requests`
for exactly that window: with it, a site still on plain HTTP has every
stylesheet, script, font and image rewritten to `https://`, where they fail,
and the visitor gets unstyled HTML with no images. Do not add the directive
back — every asset URL in the page is relative and already follows the
document's scheme, so it has nothing to upgrade and nothing to gain.

## Then — three things

1. **Turn on form notifications.** The contact and prayer form posts to Netlify
   Forms. Go to **Forms → contact → Settings → Form notifications** and add the
   church's email, or submissions will sit in the dashboard unseen.
2. **Fill in the remaining values.** Open `assets/js/site.js` and edit the block
   at the top marked `▼▼ EDIT THIS BLOCK ▼▼`: the street address, the maps link
   and the four social profile URLs. Each one is hidden until it is filled in,
   so the page never shows an empty row or a dead link — but it also never
   shows the address until you add it. Re-deploy after editing.
3. **Check the hero animates.** The emblem clip is proxied from a CDN by the
   redirect rule. If it shows a still image instead of turning, run
   `./fetch-video.sh` to download the clip into `assets/clips/` and re-deploy —
   a real file there wins over the proxy.

## What is in here

- `index.html`, `thanks/` — the site and its form confirmation page
- `assets/` — stylesheet, script, self-hosted fonts, images
- `_headers`, `_redirects`, `netlify.toml` — security headers and the clip proxy
- `README.md` — how the site is put together and what the church can edit
- `fetch-video.sh` — pulls the clip in so the site depends on nothing external
